<?php
$Servername="localhost";
$Username="root";
$password="";
$database_name="signup";

$conn=mysqli_connect($Servername,$Username,$password,$database_name);
//now check the connection
if(!$conn)
{
    die("Connection Failed:" . mysqli_connect_error());
}
 if(isset($_POST['save']))
{
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
 
    $sql_query = "INSERT INTO Signup_Form(first_name,last_name,gender,email,mobile) VALUES ('$first_name','$last_name','$gender','$email','$phone')";

     if (mysqli_query($conn, $sql_query))
    {
         echo "New Details Entry inserted successfully !";
    }
    else
    {
          echo "Error: " .$sql . "" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>